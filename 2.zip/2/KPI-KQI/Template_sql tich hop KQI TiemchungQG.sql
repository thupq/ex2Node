--SR_VN_20191022_138198
select 'VNM_IT_VTS_014' app_code, 
 v2.date2 update_time, 
case
    when  v1.baduser is null then
      round(0/v2.tong*100,2)
    else
      round(v1.baduser/v2.tong*100,2) 
    end KQI,
  case
    when v1.baduser is null then
      0
    else
      v1.baduser
    end user_fail, 
          v2.tong users
          from
(
select count(username) baduser, date1 FROM
(
select username,count(1) solan, trunc(starttime) as date1 from 
(
select 'VNM_IT_VTS_014' app_name, starttime, username,actionname, duration, errorcode
FROM TCMRADMIN.KPI_LOG
where 1=1
and starttime >=  ?
and starttime <  ?
and SERVICECODE  ='BAO_CAO_TCTE03'  
and duration>=10000   
and errorcode in ('0')   
union all
select 'VNM_IT_VTS_014' app_name, starttime, username,actionname, duration, errorcode
FROM TCMRADMIN.KPI_LOG
where 1=1
and starttime >=  ?
and starttime <  ?
and SERVICECODE  ='THEM_DOI_TUONG'  
and duration>=10000   
and errorcode in ('0')   
union all
select 'VNM_IT_VTS_014' app_name, starttime, username,actionname, duration, errorcode
FROM TCMRADMIN.KPI_LOG
where 1=1
and starttime >=  ?
and starttime <  ?
and SERVICECODE  ='BCTCTE_Tren1Tuoi_Mau03_1'  
and duration>=10000   
and errorcode in ('0')   
union all
select 'VNM_IT_VTS_014' app_name, starttime, username,actionname, duration, errorcode
FROM TCMRADMIN.KPI_LOG
where 1=1
and starttime >=  ?
and starttime <  ?
and SERVICECODE  ='THEM_LICH_SU_TIEM'  
and duration>=10000  
and errorcode in ('0')   
union all
select 'VNM_IT_VTS_014' app_name, starttime, username,actionname, duration, errorcode
FROM TCMRADMIN.KPI_LOG
where 1=1
and starttime >=  ?
and starttime <  ?
and SERVICECODE  ='DANH_SACH_HEN_TIEM'  
and duration>=10000  
and errorcode in ('0')   
union all
select 'VNM_IT_VTS_014' app_name, starttime, username,actionname, duration, errorcode
FROM TCMRADMIN.KPI_LOG
where 1=1
and starttime >=  ?
and starttime <  ?
and SERVICECODE  ='TIM_KIEM_NHANH_DOI_TUONG'  
and duration>=10000 
and errorcode in ('0')   
union all
select 'VNM_IT_VTS_014' app_name, starttime, username,actionname, duration, errorcode
FROM TCMRADMIN.KPI_LOG
where 1=1
and starttime >=  ?
and starttime <  ?
and SERVICECODE  ='TIM_KIEM_NANG_CAO_DOI_TUONG'  
and duration>=10000   
and errorcode in ('0')   
union all
select 'VNM_IT_VTS_014' app_name, starttime, username,actionname, duration, errorcode
FROM TCMRADMIN.KPI_LOG
where 1=1
and starttime >=  ?
and starttime <  ?
and SERVICECODE  ='BAO_CAO_TCTE02'  
and duration>=10000   
and errorcode in ('0')  
union all
select 'VNM_IT_VTS_014' app_name, starttime, username,actionname, duration, errorcode
FROM TCMRADMIN.KPI_LOG
where 1=1
and starttime >=  ?
and starttime <  ?
and SERVICECODE  ='LAP_KE_HOACH_TIEM' 
and duration>=10000   
and errorcode in ('0')   
union all
select 'VNM_IT_VTS_014' app_name, starttime, username,actionname, duration, errorcode
FROM TCMRADMIN.KPI_LOG
where 1=1
and starttime >=  ?
and starttime <  ?
and SERVICECODE  ='GOP_TRUNG_DOI_TUONG'  
and duration>=10000 
and errorcode in ('0')   
union all
select 'VNM_IT_VTS_014' app_name, starttime, username,actionname, duration, errorcode
FROM TCMRADMIN.KPI_LOG
where 1=1
and starttime >=  ?
and starttime <  ?
and (errorcode != '0' or errorcode like '%Exception%') 
)
group by username, trunc(starttime) having count(1) >=2
)
group by date1)v1 right join 
(select count (distinct(username)) tong, trunc(starttime) as date2 FROM TCMRADMIN.KPI_LOG 
where 1=1 
and starttime >=  ?
and starttime <  ?
and username is not null 
group by trunc(starttime))v2
on v1.date1 = v2.date2
order by date1 asc